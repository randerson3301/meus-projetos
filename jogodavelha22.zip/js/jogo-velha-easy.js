
var btnEscolhido = ""

var jog = true

var pc = 0

var identificador = 0

var valoresBtn = []

function inserirVetor() {
	if(btnQ1.value == "X") {
		valoresBtn[0] = "X"
	
	} else if(btnQ1.value == "O") {
		valoresBtn[0] = "O"
	} 
}

function inserirValor(btnEscolhido) {
	
	if(jog) {
		btnEscolhido.value = "X"
		inserirVetor()
		anular(btnEscolhido)
		
		btnEscolhido.disabled = true
		
		jog = false
	}
}

function anular(btnEscolhido) {
	while(jog) {
		if(btnEscolhido.value != "") {
			continue
		}
		
		jog = false
	}

	while(jog == false) {
		if(btnEscolhido.value != "") {
			continue
		}
		
		jog = true
	}
	
}	
	


