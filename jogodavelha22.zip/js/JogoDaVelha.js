var jogador1 = true
var btnEscolhido 
var jog = [9]

//Gets e Sets


function setBtnEscolhido( btnEscolhido) {
	this.btnEscolhido = btnEscolhido
}

function getBtnEscolhido(){
	return btnEscolhido
}

//Setar valores nos botões
function setValores(getBtnEscolhido){
	if(btnEscolhido == btnQ1 && isJogador1()) {
		btnEscolhido.value = "X"
		jog[0] = 1
		jogador1 = false
	
	} else if(btnEscolhido == btnQ1 && !isJogador1()) {
		btnEscolhido.value = "O"
		jog[0] = 2
		jogador1 = true
	
	} else if(btnEscolhido == btnQ2 && isJogador1()) {
		btnEscolhido.value = "X"
		jog[1] = 1
		jogador1 = false
	
	} else if(btnEscolhido == btnQ2 && !isJogador1()) {
		btnEscolhido.value = "O"
		jog[1] = 2
		jogador1 = true
	
	} else if(btnEscolhido == btnQ3 && isJogador1()) {
		btnEscolhido.value = "X"
		jog[2] = 1
		jogador1 = false
	
	} else if(btnEscolhido == btnQ3 && !isJogador1()) {
		btnEscolhido.value = "X"
		jog[2] = 2
		jogador1 = true
	
	} else if(btnEscolhido == btnQ4 && isJogador1()) {
		jog[3] = 1
		jogador1 = false
	
	} else if(btnEscolhido == btnQ4 && !isJogador1()) {
		jog[3] = 2
		jogador1 = true
	
	} else if(btnEscolhido == btnQ5 && isJogador1()) {
		jog[4] = 1
		jogador1 = false
	
	} else if(btnEscolhido == btnQ5 && !isJogador1()) {
		jog[4] = 2
		jogador1 = true
	
	} else if(btnEscolhido == btnQ6 && isJogador1()) {
		jog[5] = 1
		jogador1 = false
	
	} else if(btnEscolhido == btnQ6 && !isJogador1()) {
		jog[5] = 2
		jogador1 = true

	}else if(btnEscolhido == btnQ7 && isJogador1()) {
		jog[6] = 1
		jogador1 = false
	
	} else if(btnEscolhido == btnQ7 && !isJogador1()) {
		jog[6] = 2
	} else if(btnEscolhido == btnQ8 && isJogador1()) {
		jog[7] = 1
	} else if(btnEscolhido == btnQ8 && !isJogador1()) {
		jog[7] = 2
	} else if(btnEscolhido == btnQ9 && isJogador1()) {
		jog[8] = 1
	} else if(btnEscolhido == btnQ9 && !isJogador1()) {
		jog[8] = 2
	}
}

//Função para reiniciar o jogo 
function reiniciar(getBtnEscolhido) {
	btnEscolhido.disabled = false
	

	window.location.reload()
}

//Limpando todos os valores
function limparValores(getBtnEscolhido){
	setBtnEscolhido("")
	

	//voltando ao X como primeiro.			
	setJogador1(true)
}	



//Função para setar valor nos buttons
function atribuirValor(getBtnEscolhido) {
	if(isJogador1()) {
		
		btnEscolhido.value = "X"
					
		
		
		setJogador1(false)
	} else {
		
		btnEscolhido.value = "O"

		setJogador1(true)
	} 
}	
	
//Anular valor do botão
function anularButton(getBtnEscolhido) {
	if(getBtnEscolhido() != "") {
		btnEscolhido.disabled = true;
	} 
}	
		
//Função que definirá o vencedor e perdedor	
function autenticarVitoriaEDerrota() {	
	//Autenticação da vitória
	if(btnQ1.value == "X" && btnQ2.value == "X" && btnQ3.value == "X" 
		|| btnQ1.value == "X" && btnQ5.value == "X" && btnQ9.value == "X"
		|| btnQ1.value == "X" && btnQ5.value == "X" && btnQ9.value == "X"
		|| btnQ1.value == "X" && btnQ4.value == "X" && btnQ7.value == "X"
		
		|| btnQ2.value == "X" && btnQ5.value == "X" && btnQ8.value == "X"

		|| btnQ4.value == "X" && btnQ5.value == "X" && btnQ6.value == "X"
		
		|| btnQ3.value == "X" && btnQ6.value == "X" && btnQ9.value == "X"
		|| btnQ3.value == "X" && btnQ5.value == "X" && btnQ7.value == "X"
		
		|| btnQ7.value == "X" && btnQ8.value == "X" && btnQ9.value == "X"
		
		){
			alert("X IS THE WINNER!!!")
			reiniciar()
			limparValores()

	} else if (
		btnQ1.value == "O" && btnQ2.value == "O" && btnQ3.value == "O" 
		|| btnQ1.value == "O" && btnQ5.value == "O" && btnQ9.value == "O"
		|| btnQ1.vavallue == "O" && btnQ5.value == "O" && btnQ9.value == "O"
		|| btnQ1.value == "O" && btnQ4.value == "O" && btnQ7.value == "O"
		
		|| btnQ2.value == "O" && btnQ5.value == "O" && btnQ8.value == "O"
		
		|| btnQ3.value == "O" && btnQ6.value == "O" && btnQ9.value == "O"
		|| btnQ3.value == "O" && btnQ5.value == "O" && btnQ7.value == "O"
		
		|| btnQ4.value == "O" && btnQ5.value == "O" && btnQ6.value == "O"

		
		|| btnQ7.value == "O" && btnQ8.value == "O" && btnQ9.value == "O"){
		
			alert("O IS THE WINNER")
			reiniciar()
			limparValores()
	} 
}
	
		
			
function empatarJogo(){
	if (
		btnQ1.value != "" && btnQ2.value != "" && btnQ3.value != "" 
		&& btnQ4.value != "" && btnQ5.value != "" && btnQ6.value != ""
		&& btnQ7.value != "" && btnQ8.value != "" && btnQ9.value != ""
		) {
	
		alert("X e O Empataram !! ")
		reiniciar()
		limparValores()
	}
}
	
			




