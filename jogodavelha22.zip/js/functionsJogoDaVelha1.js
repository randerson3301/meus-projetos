var jog1 = true
var btnEscolhido = ""

function reiniciar() {
	btnQ1.disabled = false
	btnQ2.disabled = false
	btnQ3.disabled = false
	btnQ4.disabled = false
	btnQ5.disabled = false
	btnQ6.disabled = false
	btnQ7.disabled = false
	btnQ8.disabled = false
	btnQ9.disabled = false

	window.location.reload()
}

function limparValores(){
	//Limpando todos os valores
			btnQ1.value = ""
			btnQ2.value = ""
			btnQ3.value = ""
			btnQ4.value = ""
			btnQ5.value = ""
			btnQ6.value = ""
			btnQ7.value = ""
			btnQ8.value = ""
			btnQ9.value = ""
}


function atribuirValor(btnEscolhido) {
	if(jog1) {
		btnEscolhido.value = "X"
					
		jog1 = false
	} else {
		btnEscolhido.value = "O"

		jog1 = true
	}
}	

//Anular valor do botão, para que n seja alterado	
function anularBotao(btnEscolhido) {
	if(btnEscolhido.value != "") {
		btnEscolhido.disabled = true;
	} 
}
		
	
	
//Autenticar vitória	
function autenticarVitoria(btnEscolhido) {
 	atribuirValor(btnEscolhido)
	
	anularBotao(btnEscolhido)
	
	
	if(btnQ1.value == "X" && btnQ2.value == "X" && btnQ3.value == "X" 
		|| btnQ1.value == "X" && btnQ5.value == "X" && btnQ9.value == "X"
		|| btnQ1.value == "X" && btnQ5.value == "X" && btnQ9.value == "X"
		|| btnQ1.value == "X" && btnQ4.value == "X" && btnQ7.value == "X"
		
		|| btnQ2.value == "X" && btnQ5.value == "X" && btnQ8.value == "X"

		|| btnQ4.value == "X" && btnQ5.value == "X" && btnQ6.value == "X"
		
		|| btnQ3.value == "X" && btnQ6.value == "X" && btnQ9.value == "X"
		|| btnQ3.value == "X" && btnQ5.value == "X" && btnQ7.value == "X"
		
		|| btnQ7.value == "X" && btnQ8.value == "X" && btnQ9.value == "X"
		
		){
			alert("X IS THE WINNER!!!")
			reiniciar()
			
			limparValores()
			
			//voltando ao X como primeiro.			
			jog1 = false;	
			
	} else if (
		btnQ1.value == "O" && btnQ2.value == "O" && btnQ3.value == "O" 
		|| btnQ1.value == "O" && btnQ5.value == "O" && btnQ9.value == "O"
		|| btnQ1.vavallue == "O" && btnQ5.value == "O" && btnQ9.value == "O"
		|| btnQ1.value == "O" && btnQ4.value == "O" && btnQ7.value == "O"
		
		|| btnQ2.value == "O" && btnQ5.value == "O" && btnQ8.value == "O"
		
		|| btnQ3.value == "O" && btnQ6.value == "O" && btnQ9.value == "O"
		|| btnQ3.value == "O" && btnQ5.value == "O" && btnQ7.value == "O"
		
		|| btnQ4.value == "O" && btnQ5.value == "O" && btnQ6.value == "O"

		
		|| btnQ7.value == "O" && btnQ8.value == "O" && btnQ9.value == "O"){
			alert("O IS THE WINNER")
			reiniciar()
		
			limparValores()
	
			//voltando ao X como primeiro.			
			jog1 = true;
	}
	
	empatar()
		
			
			
}			

//O jogo será empatado	 
function empatar() {
	 if (
		btnQ1.value != "" && btnQ2.value != "" && btnQ3.value != "" 
		&& btnQ4.value != "" && btnQ5.value != "" && btnQ6.value != ""
		&& btnQ7.value != "" && btnQ8.value != "" && btnQ9.value != ""
		) {
	
			alert("X e O Empataram !! ")
			reiniciar()
			limparValores()

			jog1 = true
		}	
}
	
			



